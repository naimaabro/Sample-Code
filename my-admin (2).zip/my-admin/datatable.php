<!DOCTYPE html>
<?php include "db.php"; ?>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
<link rel="stylesheet" href="//cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css">
<script type="text/javascript" src="//cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js">

</script>
<script type="text/javascript">

$(document).ready( function () {
  $('#myDataTable').DataTable();
} );

</script>
  </head>
  <body>
    <table  id="myDataTable" width="100%" cellspacing="0">
      <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Allowance</th>
          <th>Salary</th>
          <th>Delete Record</th>
          <th>Update Record</th>
</tr>
      </thead>
      <tfoot>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Allowance</th>
          <th>Salary</th>
          <th>Delete Record</th>
          <th>Update Record</th>

        </tr>
      </tfoot>
      <tbody>
<?php
        $select="select * from salaries";
$selected=mysqli_query($con,$select);
while($row=mysqli_fetch_assoc($selected))
{
echo "<tr>";
echo "<td>".$row['id']."</td>";
echo "<td>".$row['name']."</td>";
echo "<td>".$row['allowance']."</td>";
echo "<td>".$row['salary']."</td>";
echo "<td><a href='?delete=".$row['id']."'> Delete Record</a></td>";
echo "<td><a href='update.php?update=".$row['id']."'> Update Record</a></td>";
echo "</tr>";
}
?>   </tbody>





    </table>

  </body>
</html>
