
<!DOCTYPE html>

<?php include 'db.php';
session_start(); ?>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>SB Admin 2 - Blank</title>

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
  <?php include 'sidebar.php'; ?>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
          <?php include 'topbar.php'; ?>         <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-4 text-gray-800">Edit Profile</h1>


          <?php
          if(!empty($_POST['submit']))

          {  $f_name=$_POST['f_name'];
            $l_name=$_POST['l_name'];
            $_SESSION['f_name']=$f_name;
            $_SESSION['l_name']=$l_name;
            $password=$_POST['password'];
            $repeat_password=$_POST['repeat_password'];
            if($password==$repeat_password)
            {
              if(!empty($_FILES['profile_pic']['name'])){
              $target_dir = "img/";
              $target_file = $target_dir . basename($_FILES["profile_pic"]["name"]);
              $uploadOk = 1;
              $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
              // Allow certain file formats
              if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
              && $imageFileType != "gif" ) {
                echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
                $uploadOk = 0;
              }
                            // Check file size
              if ($_FILES["profile_pic"]["size"] > 500000) {
                echo "Sorry, your file is too large.";
                $uploadOk = 0;
              }
                            // Check if $uploadOk is set to 0 by an error
              if ($uploadOk == 0) {
                echo "Sorry, your file was not uploaded.";
              // if everything is ok, try to upload file
              } else {
                if (move_uploaded_file($_FILES["profile_pic"]["tmp_name"], $target_file)) {
                  unlink($_SESSION['img']);
                  unset($_SESSION['img']);
                  $_SESSION['img']=$target_file;
                  echo "The file ". basename( $_FILES["profile_pic"]["name"]). " has been uploaded.";
                } else {
                  echo "Sorry, there was an error uploading your file.";
                }
              }
              }
              else {
                $target_file=$_SESSION['img'];
              }
              $qry="update admin set f_name='$f_name',l_name='$l_name', password='$password',img='$target_file' where email='".$_SESSION['email']."'";
              $rs=mysqli_query($con,$qry);
              if($rs) {
                echo "Profile info updated successfully";
              //  header('location:profile.php');
              }

              else {
                echo "There was an error in updating your profile info"." ".mysqli_error($con);
              }




            }

            // Check file size

            else {
              echo "Password did not match!";
            }
          }



           ?>
          <table class="table table-striped">
                    <tbody>
                       <tr>
                          <td colspan="1">
                             <form class="well form-horizontal" method="post" enctype="multipart/form-data">
                                <fieldset>
                                   <div class="form-group">
                                      <label class="col-md-4 control-label">First Name</label>
                                      <div class="col-md-8 inputGroupContainer">
                                         <div class="input-group"><span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span><input id="fullName" name="f_name" placeholder="First Name" class="form-control" required="true" value="<?php  echo $_SESSION['f_name']; ?>"  type="text"></div>
                                      </div>
                                   </div>
                                   <div class="form-group">
                                      <label class="col-md-4 control-label">Last Name</label>
                                      <div class="col-md-8 inputGroupContainer">
                                         <div class="input-group"><span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span><input id="fullName" name="l_name" placeholder="Last Name" class="form-control" required="true" value="<?php  echo $_SESSION['l_name']; ?>"  type="text"></div>
                                      </div>
                                   </div>
                                   <div class="form-group">
                                      <label class="col-md-4 control-label">Profile pic</label>
                                      <img src="<?php echo $_SESSION['img']; ?>" alt="" height="200" width="200">
                                      <div class="col-md-8 inputGroupContainer">
                                         <div class="input-group"><span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span><input id="fullName" name="profile_pic" placeholder="Upload Profile Picture" class="form-control"   type="file"></div>
                                      </div>
                                   </div>

                                   <div class="form-group">
                                      <label class="col-md-4 control-label">Password</label>
                                      <div class="col-md-8 inputGroupContainer">
                                         <div class="input-group"><span class="input-group-addon"><i class="glyphicon glyphicon-home"></i></span><input id="addressLine1" name="password" placeholder="Enter New Password" class="form-control" required="true"  type="password"></div>
                                      </div>
                                   </div>
                                   <div class="form-group">
                                      <label class="col-md-4 control-label">Confirm Password</label>
                                      <div class="col-md-8 inputGroupContainer">
                                         <div class="input-group"><span class="input-group-addon"><i class="glyphicon glyphicon-home"></i></span><input id="addressLine1" name="repeat_password" placeholder="Confirm Password" class="form-control" required="true"  type="password"></div>
                                      </div>
                                   </div>


                                   <div class="form-group">
                                      <div class="col-md-8 inputGroupContainer">
                                         <div class="input-group"><span class="input-group-addon"><i class="glyphicon glyphicon-earphone"></i></span><input id="phoneNumber" name="submit" class="form-control btn btn-primary" required="true"  type="submit" value="Edit"></div>
                                      </div>
                                   </div>
                                </fieldset>
                             </form>
                          </td>

                       </tr>
                    </tbody>
                 </table>
        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; Your Website 2020</span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="login.php">Logout</a>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

</body>

</html>
