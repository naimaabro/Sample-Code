<?php
header('Access-Control-Allow-Origin: *');
if (PHP_SAPI == 'cli-server') {
    // To help the built-in PHP dev server, check if the request was actually for
    // something which should probably be served as a static file
    $url  = parse_url($_SERVER['REQUEST_URI']);
    $file = __DIR__ . $url['path'];
    if (is_file($file)) {
        return false;
    }
}


require __DIR__ . '/../vendor/autoload.php';

use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;


session_start();

// Instantiate the app
$settings = require __DIR__ . '/../src/settings.php';
$app = new \Slim\App($settings);



// Set up dependencies
require __DIR__ . '/../src/dependencies.php';

// Register middleware
require __DIR__ . '/../src/middleware.php';

// Register routes
require __DIR__ . '/../src/routes.php';

$conn = mysqli_connect("localhost","root","","nftp");

$app->get('/hello/world',function (Request $request, Response $response) {

  echo "Hello beautiful world";


});




/*get all students */
$app->get('/salaries/show',function (Request $request, Response $response) {
  global $conn;
  $qry="SELECT salaries.name,department.department_name,salaries.allowance,salaries.salary  FROM `salaries` LEFT JOIN department ON salaries.department=department.id";
  $rs=mysqli_query($conn,$qry);
  $data=array();
  while($row=mysqli_fetch_assoc($rs)){

      $data[]=$row;

  }
$refdata['data']=$data;

	echo json_encode($refdata);
});

/*insert students */
$app->get('/students/insert',function (Request $request, Response $response) {
  global $conn;
	$data = $request->getParsedBody();
  $name=$_GET['name'];
  $degree=$_GET['degree'];
  $cgpa=$_GET['cgpa'];

$qry="insert into students(name,degree,cgpa) values('$name','$degree',$cgpa)";
$rs=mysqli_query($conn,$qry);
if($rs){

  echo "successfully inserted";
}else{

  echo "error inserting student";
}



});
$app->post('/user/post',function (Request $request, Response $response) {
  global $conn;
	$data = $request->getParsedBody();
  $first_name=$data['first_name'];
  $last_name=$data['last_name'];
  $email=$data['email'];
  $password=$data['password'];
$qry="insert into users(first_name,last_name,email,password) values('$first_name','$last_name','$email','$password')";
echo $qry;
$rs=mysqli_query($conn,$qry);
if($rs){

  echo "successfully inserted";
}else{

  echo "error inserting student";
}



});
/*insert students with post method*/
$app->post('/students/post',function (Request $request, Response $response) {
  global $conn;
	$data = $request->getParsedBody();
  $name=$data['name'];
  $degree=$data['degree'];
  $cgpa=$data['cgpa'];
  $fee=$data['fee'];
$qry="insert into students(name,degree,cgpa,fee) values('$name','$degree',$cgpa,$fee)";
//echo $qry;
$rs=mysqli_query($conn,$qry);
if($rs){

  echo "successfully inserted";
}else{

  echo "error inserting student";
}



});

/*get all derees and number of students */
$app->get('/get/degreenum',function (Request $request, Response $response) {
  global $conn;
	$data = $request->getParsedBody();
  $mode="SET sql_mode = ''";
  mysqli_query($conn,$mode);
  $qry="select count(students.id) as num_students,degree.name from students left join degree on students.degree=degree.id group by degree.id";
  $rs=mysqli_query($conn,$qry);
  $data=array();
  while($row=mysqli_fetch_assoc($rs)){

      $data[]=$row;

  }

	return json_encode($data);
});

// Run app
$app->run();
