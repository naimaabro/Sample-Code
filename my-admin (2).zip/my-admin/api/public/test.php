<?php

$conn=mysqli_connect("localhost","root","musicman","musicgateway_migrate2",3307);
if(!$conn){
    
    die('connection failed');
}

$qry=" SELECT distinct email,
       username,
       identity.id,
       project.title AS project_title,
       project.featured AS featured,
       project.pro_access AS exclusive,
       project.min_budget as min_budget,
       project.min_budget as max_budget,
       project.deadline as deadline,
       project_type.name as project_type,
       project.id AS project_id,
       profile.avatar as avatar,
       profile.profile_type as profile_type
FROM identity
LEFT JOIN profile ON identity.profile_id=profile.id
LEFT JOIN profile_skills ON profile.id=profile_skills.profile_id
LEFT JOIN project_skills ON profile_skills.skill_id=project_skills.skill_id
LEFT JOIN project ON project.id=project_skills.project_id
LEFT JOIN project_type ON project.project_mode_id=project_type.project_mode_id
LEFT JOIN skill ON profile_skills.skill_id=skill.id
LEFT JOIN identity_email_preferences ON identity.id=identity_email_preferences.identity_id
WHERE ((identity_email_preferences.licence_music=1
        AND project.project_type_id=4)
       OR (identity_email_preferences.find_talent=1
           AND project.project_type_id=2)
       OR (identity_email_preferences.find_music=1
           AND project.project_type_id=1)
       OR (identity_email_preferences.hire_people=1
           AND project.project_type_id=6)
       OR (identity_email_preferences.book_artists=1
           AND project.project_type_id=5)
       OR (identity_email_preferences.collaboration=1
           AND project.project_type_id=10)
       OR (identity_email_preferences.mastering=1
           AND skill.id=174)
       OR (identity_email_preferences.remix=1
           AND skill.id IN(138,
                           141))
       OR (identity_email_preferences.artwork=1
           AND skill.id IN (172,
                            176))
       OR (identity_email_preferences.music_videos=1
           AND skill.id IN (172,
                            176,
                            178)))
  AND project.date_created>= now()-INTERVAL 15 DAY
  AND identity.date_deleted IS NULL
  AND identity.suspended='no'
  AND identity.network_id IS NULL
  AND project.status='open'
  AND project.network_id IS NULL
  AND project.opportunity_project=1
  AND project.date_closed IS NULL";
$rs=mysqli_query($conn,$qry) or die(mysqli_error($conn));
$data=array();
$data_collected=array();

$i=0;

while($row=mysqli_fetch_assoc($rs)){

 
	$data[$row['id']]['id']=$row['id'];
    	$data[$row['id']]['email']=$row['email'];
    	$data[$row['id']]['username']=$row['username'];
	$data[$row['id']]['profile_type']=$row['profile_type'];
   $data[$row['id']]['avatar']=$row['avatar'];
	$data[$row['id']]['projects'][$i]['title'] = $row['project_title'];	
	$data[$row['id']]['projects'][$i]['id'] = $row['project_id'];
$data[$row['id']]['projects'][$i]['featured'] = $row['featured'];
        $data[$row['id']]['projects'][$i]['exclusive'] = $row['exclusive'];
    $data[$row['id']]['projects'][$i]['min_budget'] = $row['min_budget'];
        $data[$row['id']]['projects'][$i]['max_budget'] = $row['max_budget'];
        $data[$row['id']]['projects'][$i]['deadline'] = $row['deadline'];
 $data[$row['id']]['projects'][$i]['project_type'] = $row['project_type'];
$i++;
}
echo "<pre>";
print_r($data);
echo "</pre>";