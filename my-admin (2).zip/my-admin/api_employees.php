<?php
include "db.php";

$qry="select * from salaries";
$rs=mysqli_query($con,$qry);
$data=array();

while($row=mysqli_fetch_assoc($rs)){
  $data[]=$row;
}
echo JSON_encode($data);

?>
