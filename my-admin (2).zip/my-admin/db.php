<?php
$con=mysqli_connect("localhost","root","","nftp");
if(!$con){
  echo "Error connecting db";
}

 ?>
