
<?php
include 'db.php';
//echo "<pre>";
//print_r($_GET);
//echo "</pre>";
if(!empty($_GET['submit']))
{
  if(!empty($_GET['name'])){
    $name=$_GET['name'];
  }
  else{
    echo "Name is empty";
  }

  if(!empty($_GET['allowance'])){
    $allowance=$_GET['allowance'];
    }
  else{
    echo "Allowance is empty";
  }
  if(!empty($_GET['salary'])){
    $salary=$_GET['salary'];
  }
  else{
    echo "Salary is empty";
  }

  $insert="insert into salaries(name,allowance,salary) values ('$name',$allowance,$salary)";
  mysqli_query($con,$insert);


}
