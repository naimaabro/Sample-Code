<?php
/*
host= localhost
phpmyadmin username= root
pwd= ''
database name= salaries
*/
$con=mysqli_connect('localhost', 'root', '', 'nftp');

if($con){
//  echo "Succsessfully connected";
}

else {
echo "Database not connected, error occured.";

}

 ?>
