<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <h1> Employees Salaries Record</h1>

    <?php
    include 'db.php';
    //echo "<pre>";
    //print_r($_POST);
    //echo "</pre>";

    if(!empty($_GET['delete'])){
      $id=$_GET['delete'];
      $delete="delete from salaries where id=$id";
      $deleted=mysqli_query($con,$delete);
      if($deleted){
        //echo "Employee's record successfully deleted";
      }
      else "Unable to delete Employee's record";
    }

    if(!empty($_POST['submit']))
    {
      if(!empty($_POST['name'])){
        $name=$_POST['name'];
      }
      else{
        echo "Name is empty";
      }

      if(!empty($_POST['allowance'])){
        $allowance=$_POST['allowance'];
        }
      else{
        echo "Allowance is empty";
      }
      if(!empty($_POST['salary'])){
        $salary=$_POST['salary'];
      }
      else{
        echo "Salary is empty";
      }
      if(!empty($_POST['department'])){
        $department=$_POST['department'];
        }
      else{
        echo "Department name is empty";
      }

      $insert="insert into salaries(name,allowance,salary,department) values ('$name',$allowance,$salary,$department)";
      $insertion=mysqli_query($con,$insert);
    if($insertion){
      echo "Row successfully inserted";
    }
    else {
      echo "something went wrong while insering";
    }

    }
?>
<form  method="post">
  <input type="text" name="name" placeholder="Enter employee's name"><br><br>
  <input type="text" name="allowance" placeholder="Enter employee's allowance"><br><br>
  <input type="text" name="salary" placeholder="Enter employee's salary"><br><br>
  <select value="Choose Department" name="department">
    <?php
    $department_name="select * from department";
    $list_dept=mysqli_query($con,$department_name);
    while ($rwd=mysqli_fetch_assoc($list_dept)) {
?>
<option value="<?php echo $rwd['id']; ?>"><?php echo $rwd['department_name']; ?></option>
      // code...
    <?php }
    ?>

  </select>
  <input type="submit" name="submit" value="Add Record"><br><br>
</form>

<table border="2">
<thead>
<tr>
  <th> Employee ID</th>
  <th> Employee Name</th>
  <th> Residential Allowance</th>
  <th> Monthly Salary</th>
    <th> Department</th>
  <th> Delete Employee Record</th>
  <th> Update Emplyee Record</th>
</tr>
</thead>
<?php

$select="SELECT salaries.*, department.department_name FROM `salaries` LEFT JOIN department ON salaries.department=department.id";
$selected=mysqli_query($con,$select);
while($row=mysqli_fetch_assoc($selected))
{
  echo "<tr>";
  echo "<td>".$row['id']."</td>";
  echo "<td>".$row['name']."</td>";
  echo "<td>".$row['allowance']."</td>";
  echo "<td>".$row['salary']."</td>";

  echo "<td>".$row['department_name']."</td>";
  echo "<td><a href='?delete=".$row['id']."'> Delete</a></td>";
    echo "<td><a href='update.php?update=".$row['id']."'> Update</a></td>";
  echo "</tr>";
}
 ?>



</table>

  </body>
</html>
