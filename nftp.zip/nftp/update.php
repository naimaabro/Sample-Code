<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <h1> Employees Salaries Record</h1>

    <?php
    include 'db.php';
    //echo "<pre>";
    //print_r($_POST);
    //echo "</pre>";
if(!empty($_GET['update'])){
  $id=$_GET['update'];
  $select="select * from salaries where id=$id";
  $selected=mysqli_query($con,$select);
  while ($row=mysqli_fetch_assoc($selected)) {
    $id=$row['id'];
    $name=$row['name'];
        $allowance=$row['allowance'];
            $salary=$row['salary'];
                        $department=$row['department'];


  }

//  echo $name;
  //  echo $allowance;
    //  echo $salary;

}
    if(!empty($_POST['submit']))
    {
      if(!empty($_POST['name'])){
        $name=$_POST['name'];
      }
      else{
        echo "Name is empty";
      }

      if(!empty($_POST['allowance'])){
        $allowance=$_POST['allowance'];
        }
      else{
        echo "Allowance is empty";
      }
      if(!empty($_POST['salary'])){
        $salary=$_POST['salary'];
      }
      else{
        echo "Salary is empty";
      }
      if(!empty($_POST['department'])){
        $department=$_POST['department'];
      }
      else{
        echo "Department name is empty";
      }

    }

    $update="update salaries set name='$name', allowance='$allowance', salary='$salary', department='$department' where id=$id ";
    $updated=mysqli_query($con,$update);
    if($updated){
      echo "Record updated successfully";
    }
    else {
      echo "Record was not updated";
    }
?>
<form  method="post">
  <input type="text" name="name" placeholder="Enter employee's name" value="<?php echo $name; ?>" >  <br><br>
  <input type="text" name="allowance" placeholder="Enter employee's allowance" value="<?php echo $allowance; ?>" ><br><br>
  <input type="text" name="salary" placeholder="Enter employee's salary"   value="<?php echo $salary; ?>" ><br><br>
<input type="text" name="department" placeholder="Enter department"   value="<?php echo $department; ?>" ><br><br>
  <input type="submit" name="submit" value="Update Record"><br><br>
</form>


  </body>
</html>
